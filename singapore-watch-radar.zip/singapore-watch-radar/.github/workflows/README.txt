The daily sync workflow lives in daily-watch-sync.yml.
It is set to run at 09:15 Singapore time and supports manual runs.
After publishing, verify the initial manual workflow run before trusting the recurring updates.
